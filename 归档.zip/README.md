# webpack4-vue2
webpack4+vue2.x+ElementUI

# /src/static 目录会原封不动全部拷贝到 /dist/static中，
# 有需要放置的静态资源可以放在此目录

```javascript
// Echarts 按需引入模块
/*
* Licensed to the Apache Software Foundation (ASF) under one
* or more contributor license agreements.  See the NOTICE file
* distributed with this work for additional information
* regarding copyright ownership.  The ASF licenses this file
* to you under the Apache License, Version 2.0 (the
* "License"); you may not use this file except in compliance
* with the License.  You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing,
* software distributed under the License is distributed on an
* "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
* KIND, either express or implied.  See the License for the
* specific language governing permissions and limitations
* under the License.
*/

var _echarts = require("./lib/echarts");

(function () {
  for (var key in _echarts) {
    if (_echarts == null || !_echarts.hasOwnProperty(key) || key === 'default' || key === '__esModule') return;
    exports[key] = _echarts[key];
  }
})();

var _export = require("./lib/export");

(function () {
  for (var key in _export) {
    if (_export == null || !_export.hasOwnProperty(key) || key === 'default' || key === '__esModule') return;
    exports[key] = _export[key];
  }
})();

require("echarts/lib/component/dataset");

require("echarts/lib/chart/line");

require("echarts/lib/chart/bar");

require("echarts/lib/chart/pie");

require("echarts/lib/chart/scatter");

require("echarts/lib/chart/radar");

require("echarts/lib/chart/map");

require("echarts/lib/chart/tree");

require("echarts/lib/chart/treemap");

require("echarts/lib/chart/graph");

require("echarts/lib/chart/gauge");

require("echarts/lib/chart/funnel");

require("echarts/lib/chart/parallel");

require("echarts/lib/chart/sankey");

require("echarts/lib/chart/boxplot");

require("echarts/lib/chart/candlestick");

require("echarts/lib/chart/effectScatter");

require("echarts/lib/chart/lines");

require("echarts/lib/chart/heatmap");

require("echarts/lib/chart/pictorialBar");

require("echarts/lib/chart/themeRiver");

require("echarts/lib/chart/sunburst");

require("echarts/lib/chart/custom");

require("echarts/lib/component/grid");

require("echarts/lib/component/polar");

require("echarts/lib/component/geo");

require("echarts/lib/component/singleAxis");

require("echarts/lib/component/parallel");

require("echarts/lib/component/calendar");

require("echarts/lib/component/graphic");

require("echarts/lib/component/toolbox");

require("echarts/lib/component/tooltip");

require("echarts/lib/component/axisPointer");

require("echarts/lib/component/brush");

require("echarts/lib/component/title");

require("echarts/lib/component/timeline");

require("echarts/lib/component/markPoint");

require("echarts/lib/component/markLine");

require("echarts/lib/component/markArea");

require("echarts/lib/component/legendScroll");

require("echarts/lib/component/legend");

require("echarts/lib/component/dataZoom");

require("echarts/lib/component/dataZoomInside");

require("echarts/lib/component/dataZoomSlider");

require("echarts/lib/component/visualMap");

require("echarts/lib/component/visualMapContinuous");

require("echarts/lib/component/visualMapPiecewise");

require("zrender/lib/vml/vml");

require("zrender/lib/svg/svg");
```