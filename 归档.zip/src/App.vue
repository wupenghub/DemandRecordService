<template>
  <div id="app">
    <el-container>
      <template v-if="layoutStyle === '0'">
        <sys-header-top class="w100p"/>
        <sys-tab style="height: 40px;"/>
        <el-main class="w100p">
          <transition name="slide-fade">
            <router-view v-if="routerActive"/>
          </transition>
        </el-main>
      </template>
      <template v-else>
        <el-container class="app-item">
          <div class="aside-item">
            <sys-aside :isCollapse="isCollapse"/>
          </div>
          <div class="main-item">
            <sys-header-aside @switchAside="switchAside" class="w100p"/>
            <sys-tab style="height: 40px;"/>
            <el-main class="w100p">
              <transition name="slide-fade">
                <router-view v-if="routerActive"/>
              </transition>
            </el-main>
          </div>
        </el-container>
      </template>
    </el-container>
  </div>
</template>

<script>
  import {sysHeaderTop, sysTab} from '#/layout/topSide'
  import {sysHeaderAside, sysAside} from '#/layout/aside'
  import {mapGetters, mapMutations} from 'vuex'

  export default {
    name: "App",
    provide() {
      return {
        // 根组件提供一个appReload，供所有子组件更新app组件路由
        appReload: this.appReload,
        theme: {
          backgroundColor: '#545c64',
          activeTextColor: '#ffd04b',
          textColor: '#fff'
        }
      }
    },
    components: {sysHeaderTop, sysHeaderAside, sysTab, sysAside},
    created() {
      // 从缓存中获取主题相关数据，存入vuex中
      const openStyle = util.getCache('openstyle', {type: 'localStorage'})
      openStyle && this.setOpenStyle(openStyle)
      // 从缓存中获取layout风格相关数据，存入vuex中
      const layoutStyle = util.getCache('layoutStyle', {type: 'localStorage'})
      layoutStyle && this.setLayoutStyle(layoutStyle)
    },
    data() {
      return {
        routerActive: true,
        isCollapse: false
      };
    },
    methods: {
      ...mapMutations(['addTagViews', 'setOpenStyle', 'setLayoutStyle']),
      appReload() {
        this.routerActive = false
        this.$nextTick(() => (this.routerActive = true))
      },
      switchAside() {
          this.isCollapse = !this.isCollapse
      }
    },
    computed: {
      ...mapGetters([
        'tagViews', 'layoutStyle'
      ])
    }
  };
</script>

<style scoped lang="scss">
  .app-item {
    display: flex;
  }

  .main-item {
    flex: 1;
    overflow: auto;
  }

  #app {
    font-family: "Avenir", Helvetica, Arial, sans-serif;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    color: #2c3e50;

    section {
      overflow: hidden;
      position: absolute;
      left: 0;
      right: 0;
      top: 0;
      bottom: 0;
    }

    .el-container:not(.app-item) {
      flex-direction: column;
    }
  }

  .el-main {
    height: calc(100% - 90px);
    overflow-y: auto;
    overflow-x: hidden;
    padding: 0px;
  }

  .slide-fade-enter-active {
    transition: all 0.3s ease;
  }

  .slide-fade-leave-active {
    /* transition: all .8s cubic-bezier(1.0, 0.5, 0.8, 1.0); */
    transition: none;
    display: none;
  }

  .slide-fade-enter {
    transform: translateY(-10px);
    opacity: 0;
  }
</style>
