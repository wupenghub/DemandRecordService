<!-- 渐变柱状图 -->
<template>
  <div ref="bar"></div>
</template>

<script>
  // 引入基本模板
  let echarts = require('echarts/lib/echarts')
  // 引入柱状图组件
  require('echarts/lib/chart/bar')
  // 引入提示框和title组件
  require('echarts/lib/component/tooltip')
  require('echarts/lib/component/title')
  // 引入缩放组件
  require("echarts/lib/component/dataZoom")

  export default {
    props: {
      // 传入的数据
      // [
      //   {name: '者', value: 330},
      //   {name: '两', value: 310},
      // ]
      data: {
        type: Array,
        require: true
      },
      // 从数据获取x轴数据的字段
      label: {
        type: String,
        default: 'name'
      },
      // 从数据湖区y轴数据的字段
      value: {
        type: String,
        default: 'value'
      },
      // 鼠标滚轮缩放
      wheelZoom: {
        type: Boolean,
        default: true
      },
      // 点击柱状图缩放
      clickZoom: {
        type: Boolean,
        default: false
      },
      // 标题
      title: {
        type: String,
        default: ''
      },
      // 二级标题
      subtext: {
        type: String,
        default: ''
      }
    },
    computed: {
      // 洗数据
      chartData() {
        let dataAxis = [], data = []
        this.data.forEach(v => {
          dataAxis.push(v[this.label])
          data.push(v[this.value])
        })
        return {dataAxis, data}
      }
    },
    mounted() {
      this.drawBar()
    },
    methods: {
      // echarts绘制
      drawBar() {
        let yMax = 500, dataShadow = [], myChart = echarts.init(this.$refs.bar)
        let {dataAxis, data} = this.chartData
        let i = 0, len = data.length

        for (; i < len; i++) {
          dataShadow.push(yMax)
        }

        let option = {
          title: {
            text: this.title,
            subtext: this.subtext,
            left: 'center'
          },
          tooltip: {},
          xAxis: {
            data: dataAxis,
            axisLabel: {
              // inside: true,
              textStyle: {
                color: '#000'
              }
            },
            axisTick: {
              show: false
            },
            axisLine: {
              show: false
            },
            z: 10
          },
          yAxis: {
            axisLine: {
              show: false
            },
            axisTick: {
              show: false
            },
            axisLabel: {
              textStyle: {
                color: '#999'
              }
            }
          },
          series: [
            { // For shadow
              type: 'bar',
              itemStyle: {
                normal: {color: 'rgba(0,0,0,0.05)'}
              },
              barGap: '-100%',
              barCategoryGap: '40%',
              data: dataShadow,
              animation: false
            },
            {
              type: 'bar',
              itemStyle: {
                normal: {
                  color: new echarts.graphic.LinearGradient(
                      0, 0, 0, 1,
                      [
                        {offset: 0, color: '#293d52'},
                        {offset: 0.5, color: '#095b91'},
                        {offset: 1, color: '#123c73'}
                      ]
                  )
                },
                emphasis: {
                  color: new echarts.graphic.LinearGradient(
                      0, 0, 0, 1,
                      [
                        {offset: 0, color: '#293d52'},
                        {offset: 0.5, color: '#095b91'},
                        {offset: 1, color: '#123c73'}
                      ]
                  )
                }
              },
              data: data
            }
          ]
        }

        this.wheelZoom && Object.assign(option, {dataZoom: [{type: 'inside'}]})

        myChart.setOption(option)

        // Enable data zoom when user click bar.
        var zoomSize = 6
        myChart.on('click', params => {
          this.$emit('click', params)
          // console.log(dataAxis[Math.max(params.dataIndex - zoomSize / 2, 0)])
          this.clickZoom && myChart.dispatchAction({
            type: 'dataZoom',
            startValue: dataAxis[Math.max(params.dataIndex - zoomSize / 2, 0)],
            endValue: dataAxis[Math.min(params.dataIndex + zoomSize / 2, data.length - 1)]
          })
        })

        window.addEventListener('resize', () => myChart.resize())
      }
    }
  }
</script>