// 普通柱状图
export {default as normalBar} from './barEchartNormal.vue'
// 渐变柱状图
export {default as gradientBar} from './barEchartGradient.vue'
// 普通折线图
export {default as normalLine} from './lineEchartNormal.vue'
//  折线图，柱状图混合
export {default as lineBarMix} from './lineBarMix.vue'
// 普通饼图
export {default as normalPie} from './pieEchartNormal.vue'