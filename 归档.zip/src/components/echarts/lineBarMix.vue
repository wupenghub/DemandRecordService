<!-- 折线图，柱状图混合 -->
<template>
  <div ref="line"></div>
</template>

<script>
  // 引入基本模板
  let echarts = require('echarts/lib/echarts')
  // 引入折线图组件
  require('echarts/lib/chart/line')
  // 引入提示框和title组件
  require('echarts/lib/component/tooltip')
  require('echarts/lib/component/title')
  // 引入图例组件
  require("echarts/lib/component/legendScroll")
  require('echarts/lib/component/legend')

  export default {
    props: {
      data: {
        type: Array,
        require: true
      },
      // 从数据中获取图例的字段
      legendName: {
        type: String,
        default: 'name'
      },
      // 从数据获取x轴数据的字段
      label: {
        type: String,
        default: 'xAxis'
      },
      // 从数据湖区y轴数据的字段
      value: {
        type: String,
        default: 'value'
      },
      // 从数据中获取 当前组是什么图，可选（line | bar）两种，默认 line
      itemType: {
        type: String,
        default: 'type'
      },
      // 从数据中获取当前组是否是平滑曲线字段，
      // 数据中的smooth如果为truth就为曲线，否则为折现
      smooth: {
        type: String,
        default: 'smooth'
      },
      // 标题
      title: {
        type: String,
        default: ''
      },
      // 二级标题
      subtext: {
        type: String,
        default: ''
      },
      // 是否开启堆叠模式，如果false表示不开启
      // 传入字符串表示开启，并且以该字符串作为stack name
      stack: {
        type: [String, Boolean],
        default: false
      }
    },
    mounted() {
      this.drawChart()
    },
    computed: {
      chartData() {
        let dataXAxis = [], dataLegend = [], data = [], temp = []
        const {label, legendName, value, itemType, smooth} = this
        this.data.forEach(v => {
          dataXAxis.push(v[label])
          dataLegend.push(v[legendName])
          if (temp.includes(v[legendName])) {
            const index = temp.findIndex(ele => ele === v[legendName])
            data[index].data.push(v[value])
          } else {
            temp.push(v[legendName])
            let obj = {
              name: v[legendName],
              type: v[itemType] || 'line',
              smooth: !!v[smooth],
              data: [v[value]],
            }
            if (this.stack && typeof this.stack === 'string') {
              Object.assign(obj, {stack: this.stack})
            }
            data.push(obj)
          }
        })
        return {
          dataXAxis: Array.from(new Set(dataXAxis)),
          dataLegend: Array.from(new Set(dataLegend)),
          data
        }
      }
    },
    methods: {
      drawChart() {
        let myChart = echarts.init(this.$refs.line)
        let {dataXAxis, dataLegend, data} = this.chartData
        let option = {
          title: {
            text: this.title,
            subtext: this.subtext,
            x: 'center'
          },
          tooltip: {
            trigger: 'axis'
          },
          legend: {
            top: 30,
            data: dataLegend
          },
          grid: {
            left: '3%',
            right: '4%',
            bottom: '3%',
            containLabel: true
          },
          toolbox: {
            feature: {
              saveAsImage: {}
            }
          },
          xAxis: {
            type: 'category',
            boundaryGap: true,
            data: dataXAxis
          },
          yAxis: {
            type: 'value'
          },
          series: data
        }

        myChart.setOption(option)

        myChart.on('click', params => {
          this.$emit('click', params)
        })
        window.addEventListener('resize', () => myChart.resize())
      }
    }
  }
</script>
