<!-- 常规折线图 -->
<template>
  <div ref="line"></div>
</template>

<script>
  // 引入基本模板
  let echarts = require('echarts/lib/echarts')
  // 引入折线图组件
  require('echarts/lib/chart/line')
  // 引入提示框和title组件
  require('echarts/lib/component/tooltip')
  require('echarts/lib/component/title')
  // 引入图例组件
  require("echarts/lib/component/legendScroll")
  require('echarts/lib/component/legend')
  export default {
    props: {
      // 传入的数据
      // [
      //   {name: '者', value: 330},
      //   {name: '两', value: 310},
      // ]
      data: {
        type: Array,
        require: true
      },
      // 从数据获取x轴数据的字段
      label: {
        type: String,
        default: 'name'
      },
      // 从数据湖区y轴数据的字段
      value: {
        type: String,
        default: 'value'
      },
      // 标题
      title: {
        type: String,
        default: ''
      },
      // 二级标题
      subtext: {
        type: String,
        default: ''
      }
    },
    mounted() {
      this.drawChart()
    },
    computed: {
      chartData() {
        let dataXAxis = [], data = []
        this.data.forEach(v => {
          dataXAxis.push(v[this.label])
          data.push(v[this.value])
        })
        return {dataXAxis, data}
      }
    },
    methods: {
      drawChart() {
        let myChart = echarts.init(this.$refs.line)
        let {dataXAxis, data} = this.chartData
        let option = {
          title: {
            text: this.title,
            subtext: this.subtext,
            left: 'center'
          },
          tooltip: {},
          xAxis: {
            type: 'category',
            data: dataXAxis
          },
          yAxis: {
            type: 'value'
          },
          series: [{
            data: data,
            type: 'line',
            itemStyle: {normal: {label: {show: true}}}
          }]
        }

        myChart.setOption(option)

        myChart.on('click', params => {
          this.$emit('click', params)
        })
        window.addEventListener('resize', () => myChart.resize())
      }
    }
  }
</script>

<style lang="less" scoped>

</style>
