<template>
  <div ref="pie"></div>
</template>

<script>
  // 引入基本模板
  let echarts = require('echarts/lib/echarts')
  // 引入饼图组件
  require('echarts/lib/chart/pie')
  // 引入提示框和title组件
  require('echarts/lib/component/tooltip')
  require('echarts/lib/component/title')
  // 引入图例组件
  require("echarts/lib/component/legendScroll")
  require('echarts/lib/component/legend')

  export default {
    props: {
      // 传入的数据
      // [
      //   {name: '者', value: 330},
      //   {name: '两', value: 310},
      // ]
      data: {
        type: Array,
        require: true
      },
      // 从数据获取x轴数据的字段
      label: {
        type: String,
        default: 'name'
      },
      // 从数据湖区y轴数据的字段
      value: {
        type: String,
        default: 'value'
      },
      // 标题
      title: {
        type: String,
        default: ''
      },
      // 二级标题
      subtext: {
        type: String,
        default: ''
      },
      seriesName: {
        type: String,
        default: ''
      }
    },
    mounted() {
      this.drawCharts()
    },
    computed: {
      chartData() {
        let ldata = [], data = []
        this.data.forEach(v => {
          ldata.push(v[this.label])
          data.push({value: v[this.value], name: v[this.label]})
        })
        return {ldata, data}
      }
    },
    methods: {
      drawCharts() {
        let myChart = echarts.init(this.$refs.pie)
        let {ldata, data} = this.chartData
        let option = {
          title: {
            text: this.title,
            subtext: this.subtext,
            x: 'center'
          },
          tooltip: {
            trigger: 'item',
            formatter: "{a} <br/>{b} : {c} ({d}%)"
          },
          legend: {
            show: true,
            type: 'scroll',
            orient: 'horizontal',
            left: 'center',
            bottom: 'bottom',
            data: ldata
          },
          series: [
            {
              name: this.seriesName,
              type: 'pie',
              radius: '55%',
              center: ['50%', '60%'],
              data,
              itemStyle: {
                emphasis: {
                  shadowBlur: 10,
                  shadowOffsetX: 0,
                  shadowColor: 'rgba(0, 0, 0, 0.5)'
                }
              }
            }
          ]
        }

        myChart.setOption(option)

        myChart.on('click', params => {
          this.$emit('click', params)
        })
        window.addEventListener('resize', () => myChart.resize())
      }
    }
  }
</script>
