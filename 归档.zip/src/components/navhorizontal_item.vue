/*
横向导航条 item组件
usage：
<el-menu
  :default-active="activeIndex"
  class="app-header"
  router
  mode="horizontal"
  @select="handleSelect"
  background-color="#545c64"
  text-color="#fff"
  active-text-color="#ffd04b"
>
  <navbar v-for="(item, index) in list" :key="index" :item="item"></navbar>
</el-menu>
*/
<template>
  <!-- 有子目录 -->
  <el-submenu v-if="item[children]" :index="item[id]">
    <template slot="title">
      <i v-if="item[icon]" :class="item[icon]"></i>

      <span slot="title">{{item[name]}}</span>
    </template>
    <template v-for="sitem in item[children]">
      <!--子目录也有子目录-->
      <navbar :key="sitem[id]" v-if="sitem[children]" :item="sitem"></navbar>
      <!--子目录无子目录，是a链接跳转-->
      <el-menu-item
        :disabled="sitem[disabled]"
        v-else-if="sitem[location]"
        :index="sitem[path]"
      >
        <a :href="sitem[path]" target="_blank">
          <i v-if="sitem[icon]" :class="sitem[icon]"></i>
          {{sitem[name]}}
        </a>
      </el-menu-item>
      <!--子目录无子目录，是路由跳转-->
      <el-menu-item
        :disabled="sitem[disabled]"
        v-else
        :index="sitem[path]"
      >
        <router-link class="nav-link-router" :to="sitem.path"
                     :target="(sitem.location || openStyle === '1') ? '_blank' : '_self'">
          <i v-if="sitem[icon]" :class="sitem[icon]"></i>
          {{sitem[name]}}
        </router-link>
      </el-menu-item>
    </template>
  </el-submenu>
  <!-- 无子目录，是a链接跳转 -->
  <el-menu-item v-else-if="item[location]" :disabled="item[disabled]" :index="item[path]">
    <a :href="item[path]" target="_blank">
      <i v-if="item[icon]" :class="item[icon]"></i>
      {{item[name]}}
    </a>
  </el-menu-item>
  <!-- 无子目录，是路由跳转 -->
  <el-menu-item v-else :disabled="item[disabled]" :index="item[path]">
    <template>
      <router-link class="nav-link-router top-route-link" :to="item.path"
                   :target="(item.location || openStyle === '1') ? '_blank' : '_self'">
        <i v-if="item[icon]" :class="item[icon]"></i>
      </router-link>
      <span class="top-route-slot" slot="title">{{item[name]}}</span>
    </template>
  </el-menu-item>
</template>
<script>
  export default {
    name: "Navbar",
    props: {
      item: {
        type: Object,
        retuired: true
      },
      // 以下参数为传入的json对应的字段，不传使用默认值
      // 节点id
      id: {
        type: String,
        default: "id"
      },
      // 节点路由
      path: {
        type: String,
        default: "path"
      },
      // 节点子目录
      children: {
        type: String,
        default: "children"
      },
      // 是否是a标签
      location: {
        type: String,
        default: "location"
      },
      // 节点名称
      name: {
        type: String,
        default: "name"
      },
      // 节点是否禁用
      disabled: {
        type: String,
        default: "disabled"
      },
      // 字体图标
      icon: {
        type: String,
        default: 'icon'
      }
    },
    computed: {
      openStyle() {
        return this.$store.getters.openStyle
      }
    }
  };
</script>
<style scoped lang="scss">
  .nav-link-router {
    color: #fff !important;
    height: 100%;
    display: block;
  }

  .el-menu-item.is-active .router-link-exact-active {
    color: inherit !important;
  }

  .top-route-link {
    position: absolute;
  }

  .top-route-slot {
    margin-left: 30px;
  }
</style>
