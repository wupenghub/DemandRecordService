import Qs from 'qs'

export default {
  // ajax统一门户地址
  baseURL: 'http://47.96.76.172:4005/xh_project'
  // 设置post请求Cotent-Type
  , 'Post-Content-Type': 'application/x-www-form-urlencoded'
  // 对data进行任意转换处理，post请求参数处理
  , transformRequest: [data => Qs.stringify(data)]
  // 设置超时，0代表不设置超时
  , timeout: 30000
  // 设置ajax是否开启加载动画字段
  , NO_COVER: 'NO_COVER'
  // 设置ajax是否开启加载动画值，如果参数传入这个值，代表需要开启
  , COVER_VAL: 1
}
