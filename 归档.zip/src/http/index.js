import axios from 'axios'
import CONFIG from './http.config'
// import Vue from 'vue'

// let loading = {close: _ => ''}, needCover = 0

axios.defaults.headers.post['Content-Type'] = CONFIG['Post-Content-Type']
axios.defaults.transformRequest = CONFIG.transformRequest
axios.defaults.baseURL = CONFIG.baseURL
axios.defaults.timeout = CONFIG.timeout

// 请求拦截器
axios.interceptors.request.use(
  config => {
    // 参数 NO_COVER != COVER_VAL 代表【需要开启加载动画】
    // 请求参数带有 NO_COVER: 1，表示不需要开启ajax遮罩层
    config.data = config.data || {}
    // if (config.data[CONFIG.NO_COVER] != CONFIG.COVER_VAL) {
    //   needCover++
    //   loading = Vue.prototype.$loading({
    //     text: '加载中...'
    //     , spinner: 'el-icon-loading'
    //     , background: 'rgba(0, 0, 0, 0.1)'
    //   })
    // }
    return config
  },
  err => {
    return Promise.reject(err)
  }
)

// 数据处理器
axios.interceptors.response.use(
  res => {
    const cfg = res && res.config && res.config.data || ''
      , reg = new RegExp('(^|&)' + CONFIG.NO_COVER + '=([^&]*)(&|$)')
      , r = cfg.match(reg)
    if (r != null) {
      if (unescape(decodeURI(r[2])) != CONFIG.COVER_VAL) {
        // needCover--
      }
    } else {
      // needCover--
    }
    // if (needCover <= 0) {
    //   Vue.nextTick(_ => loading.close())
    // }
    return res.data
  },
  err => {
    // if (--needCover <= 0) {
    //   loading.close()
    // }
    return Promise.reject(err)
  }
)

export default axios
