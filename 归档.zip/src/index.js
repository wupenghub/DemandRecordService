// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import App from './App' // 侧边栏导航模式
// import App from './AppAside' // 头部导航模式
import router from './router/router'
import store from './store/index'
import axios from './http/index'
import ElementUI from 'element-ui'
import NProgress from 'nprogress'
import util from './util'

import 'nprogress/nprogress.css'
// import 'element-ui/lib/theme-chalk/index.css'
import './element-variables.scss'
import '@/css/base.css'

Vue.config.productionTip = false
Vue.use(ElementUI)

Object.assign(Vue.prototype, {
  http: axios,
  util
})

router.beforeEach((to, from, next) => {
  NProgress.start()
  next()
})

router.afterEach((to, from, next) => {
  store.commit('routerStatus', to)
  NProgress.done()
})

/* eslint-disable no-new */
new Vue({
  el: '#app',
  router,
  store,
  components: {App},
  template: '<App/>'
})
