/* 常用混入 */

/**
 * 列表分页
 * @param size                  // 给后台发送【参数】第几页，默认为`size`
 * @param pageNumber            // 给后台发送【参数】一页大小，默认为`pageNumber`
 * @param pageSizes             // 表格切换一页多少条字典，默认为`pageSizes`
 * @param tableLayout           // 表格下标显示那个功能，默认为`tableLayout`
 * @param renderTable           // 列表初始化列表的【方法名】，默认为`renderTable`
 * @param handleSizeChange      // 列表修改一页大小【方法名】，默认为`handleSizeChange`
 * @param handleCurrentChange   // 列表页数变更【方法名】，默认为`handleSizeChange`
 * @param indexMethod           // 列表序号的【方法名】，默认为`indexMethod`
 * eg:
 * import * as MIX from '@/mix.js'
 * export default{ mixins: [MIX.PAGEHANDLE()] ... }
 */
export const PAGEHANDLE = (option = {}) => {
  const {
    size = 'size'
    , pageNumber = 'pageNumber'
    , pageSizes = 'pageSizes'
    , tableLayout = 'tableLayout'
    , renderTable = 'renderTable'
    , handleSizeChange = 'handleSizeChange'
    , handleCurrentChange = 'handleCurrentChange'
    , indexMethod = 'indexMethod'
  } = option

  return {
    data() {
      return {
        tableHeaderStyle: {/*backgroundColor: 'rgba(0, 0, 0, .2)', color: '#fff'*/},
        [pageNumber]: 1,
        [size]: 10,
        [pageSizes]: [10, 20, 50, 100],
        [tableLayout]: 'total, sizes, prev, pager, next, jumper'
      }
    },
    methods: {
      /**
       * 分页 每页多少条
       * @param val
       */
      [handleSizeChange](val) {
        this[size] = val
        this[renderTable](this[pageNumber], val)
      },
      /**
       * 分页 当前第几页
       * @param val
       */
      [handleCurrentChange](val) {
        this[pageNumber] = val
        this[renderTable](val, this[size])
      },
      /**
       * 初始化索引
       * @param index
       * @returns {*}
       */
      [indexMethod](index) {
        const currPage = this[pageNumber], currSize = this[size]
        return (currPage - 1) * currSize + index + 1
      }
    }
  }
}
