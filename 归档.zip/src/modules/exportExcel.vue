<template>
  <div class="p5">
    <el-row>
      <el-button @click="exportExcel" type="primary">导出数据</el-button>
    </el-row>
    <el-table
      :data="jsonData"
      style="width: 100%">
      <el-table-column
        prop="name"
        label="名字"
        width="180">
      </el-table-column>
      <el-table-column
        prop="phone"
        label="电话"
        width="180">
      </el-table-column>
      <el-table-column
        prop="email"
        label="邮箱">
      </el-table-column>
    </el-table>
  </div>
</template>

<script>
  export default {
    methods: {
      // 导出Excel
      exportExcel() {
        import('@/excelAPI/Export2Excel').then(excel => {
          // 表格的表头列表
          const tHeader = ['名字', '电话', '邮箱']
          // 与表头相对应的数据里边的字段
          const filterVal = ['name', 'phone', 'email']
          //这里还是使用export_json_to_excel方法比较好，方便操作数据
          excel.export_json_to_excel({
            header: tHeader,
            data: this.formatJson(filterVal, this.jsonData),
            filename: '导出数据',
            autoWidth: true
          })
        })
      },
      /**
       * 洗数据
       * @param filterVal
       * @param jsonData
       * 转换成如下格式：
       * [Array(3), Array(3), Array(3), Array(3)]
       * 0: (3) ["路人甲", "123456", "123@123456.com"]
       * 1: (3) ["炮灰乙", "123456", "123@123456.com"]
       * 2: (3) ["土匪丙", "123456", "123@123456.com"]
       * 3: (3) ["流氓丁", "123456", "123@123456.com"]
       */
      formatJson(filterVal, jsonData) {
        return jsonData.map(v => filterVal.map(j => v[j]))
      },
    },
    data() {
      return {
        jsonData: [
          {
            name: '路人甲',
            phone: '123456',
            email: '123@123456.com'
          },
          {
            name: '炮灰乙',
            phone: '123456',
            email: '123@123456.com'
          },
          {
            name: '土匪丙',
            phone: '123456',
            email: '123@123456.com'
          },
          {
            name: '流氓丁',
            phone: '123456',
            email: '123@123456.com'
          }
        ]
      }
    }
  }
</script>
