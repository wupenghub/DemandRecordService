<template>
  <div id="content">
    <div class="header">header</div>
    <div class="menu">menu</div>
    <div class="content">content</div>
    <div class="footer">footer</div>
  </div>
</template>

<script>
  export default {
    data() {
      return {}
    }
  }
</script>
<style lang="scss" scoped>
  $-layout-gap: 5px;

  #content {
    height: 100%;
    padding: $-layout-gap $-layout-gap 0 $-layout-gap;

    /*开启网格模式*/
    display: grid;

    /*设置成3列，每列宽度相同*/
    grid-template-columns: repeat(12, 1fr);

    /*虽然上面已经可以自动计算行数，但是这里还是可以设置行数和每行的高度*/
    grid-template-rows: 60px calc(100% - 120px  - #{$-layout-gap * 3}) 60px;

    /*设置row的最小高度和最大高度，最大高度取auto后便可以让row的高度自适应*/
    /*grid-auto-rows: minmax(60px, auto);*/

    /*设置每个item间隔*/
    grid-gap: $-layout-gap;

    /*设置网络区域（模板区域*/
    /*空白区域可以使用 . 符号占位*/
    grid-template-areas:
      "h h h h h h h h h h h h"
      "m m c c c c c c c c c c"
      "f f f f f f f f f f f f";
    /*"h h h h h h h h h h h h"
    "m m . c c c c c c c c c"
    "f f f f f f f f f f f f";*/
  }

  /*类名与网格中的网格项建立对应的连接 START*/
  .header {
    grid-area: h;
  }

  .menu {
    grid-area: m;
  }

  .content {
    grid-area: c;
  }

  .footer {
    grid-area: f;
  }
  /*类名与网格中的网格项建立对应的连接 END*/

  #content div {
    background: lightgrey;
    padding: 30px;
  }

  #content div:nth-child(even) {
    background: skyblue;
  }
</style>