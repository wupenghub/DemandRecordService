<template>
  <div class="index-layout h100p p5">
    <div class="left-top">
      <gradient-bar
        class="w100p h100p"
        @click="gradientBarClick"
        :data="gradientBarData"
        title="渐变柱状图"
        subtext="二级标题二级标题"
      />
    </div>
    <div class="main-content-t">
      <line-bar-mix
        class="w100p h100p"
        @click="stackLineClick"
        :data="stackLineData"
        title="折线图，柱状图混合"
        stack="总量"
      />
    </div>
    <div class="main-content-b">
      <gradient-bar
        class="w100p h100p"
        @click="gradientBarClick"
        :data="gradientBarData"
        title="渐变柱状图"
        subtext="二级标题二级标题"
      />
    </div>
    <div class="right-top">
      <normal-pie
        class="w100p h100p"
        @click="normalPieClick"
        :data="normalPieData"
        seriesName="访问来源"
        title="常规饼图"
        subtext="二级标题二级标题"
      />
    </div>
    <div class="left-bottom">
      <normal-bar
        class="w100p h100p"
        @click="normalBarClick"
        :data="normalBarData"
        title="常规柱状图"
        subtext="二级标题二级标题"
      />
    </div>
    <div class="right-bottom">
      <normal-line
        class="w100p h100p"
        @click="normalLineClick"
        :data="normalLineData"
        title="常规折线图"
        subtext="二级标题二级标题"
      />
    </div>
  </div>
</template>

<script>
  import {gradientBar, normalBar, normalPie, normalLine, lineBarMix} from '@/components/echarts/'

  export default {
    components: {gradientBar, normalBar, normalPie, normalLine, lineBarMix},
    data() {
      return {
        gradientBarData: [
          {name: '点', value: 220},
          {name: '击', value: 182},
          {name: '柱', value: 191},
          {name: '子', value: 234},
          {name: '或', value: 290},
          {name: '者', value: 330},
          {name: '两', value: 310},
          {name: '指', value: 123},
          {name: '在', value: 442},
          {name: '触', value: 321},
          {name: '屏', value: 90},
          {name: '上', value: 149},
          {name: '滑', value: 210},
          {name: '动', value: 122},
          {name: '能', value: 133},
          {name: '够', value: 334},
          {name: '自', value: 198},
          {name: '动', value: 123},
          {name: '缩', value: 125},
          {name: '放', value: 220},
        ],
        normalBarData: [
          {name: 'Mon', value: 120},
          {name: 'Tue', value: 200},
          {name: 'Wed', value: 150},
          {name: 'Thu', value: 80},
          {name: 'Fri', value: 70},
          {name: 'Sat', value: 110},
          {name: 'Sun', value: 130},
        ],
        normalPieData: [
          {value: 335, name: '直接访问'},
          {value: 310, name: '邮件营销'},
          {value: 234, name: '联盟广告'},
          {value: 135, name: '视频广告'},
          {value: 1548, name: '搜索引擎'}
        ],
        normalLineData: [
          {name: 'Mon', value: 820},
          {name: 'Tue', value: 932},
          {name: 'Wed', value: 901},
          {name: 'Thu', value: 934},
          {name: 'Fri', value: 1290},
          {name: 'Sat', value: 1330},
          {name: 'Sun', value: 1320},
        ],
        stackLineData: [
          {xAxis: '周一', name: '邮件营销', value: 120},
          {xAxis: '周二', name: '邮件营销', value: 132},
          {xAxis: '周三', name: '邮件营销', value: 101},
          {xAxis: '周四', name: '邮件营销', value: 134},
          {xAxis: '周五', name: '邮件营销', value: 90},
          {xAxis: '周六', name: '邮件营销', value: 230},
          {xAxis: '周日', name: '邮件营销', value: 210},
          {xAxis: '周一', name: '联盟广告', value: 220},
          {xAxis: '周二', name: '联盟广告', value: 182},
          {xAxis: '周三', name: '联盟广告', value: 191},
          {xAxis: '周四', name: '联盟广告', value: 234},
          {xAxis: '周五', name: '联盟广告', value: 290},
          {xAxis: '周六', name: '联盟广告', value: 330},
          {xAxis: '周日', name: '联盟广告', value: 310},
          {xAxis: '周一', name: '视频广告', value: 150},
          {xAxis: '周二', name: '视频广告', value: 232},
          {xAxis: '周三', name: '视频广告', value: 201},
          {xAxis: '周四', name: '视频广告', value: 154},
          {xAxis: '周五', name: '视频广告', value: 190},
          {xAxis: '周六', name: '视频广告', value: 330},
          {xAxis: '周日', name: '视频广告', value: 410},
          {xAxis: '周一', name: '直接访问', value: 320, type: 'bar'},
          {xAxis: '周二', name: '直接访问', value: 332, type: 'bar'},
          {xAxis: '周三', name: '直接访问', value: 301, type: 'bar'},
          {xAxis: '周四', name: '直接访问', value: 334, type: 'bar'},
          {xAxis: '周五', name: '直接访问', value: 390, type: 'bar'},
          {xAxis: '周六', name: '直接访问', value: 330, type: 'bar'},
          {xAxis: '周日', name: '直接访问', value: 320, type: 'bar'},
          {xAxis: '周一', name: '搜索引擎', value: 820, smooth: true},
          {xAxis: '周二', name: '搜索引擎', value: 932, smooth: true},
          {xAxis: '周三', name: '搜索引擎', value: 901, smooth: true},
          {xAxis: '周四', name: '搜索引擎', value: 934, smooth: true},
          {xAxis: '周五', name: '搜索引擎', value: 1290, smooth: true},
          {xAxis: '周六', name: '搜索引擎', value: 1330, smooth: true},
          {xAxis: '周日', name: '搜索引擎', value: 1320, smooth: true},
        ]
      }
    },
    methods: {
      gradientBarClick(params) {
        console.log(params)
      },
      normalBarClick(params) {
        console.log(params)
      },
      normalPieClick(params) {
        console.log(params)
      },
      normalLineClick(params) {
        console.log(params)
      },
      stackLineClick(params) {
        console.log(params)
      }
    }
  }
</script>

<style lang="scss" scoped>
  $-layout-gap: 5px;

  .index-layout {

    /*> div {
      box-shadow: 0px 0px 4px 0px rgba(0, 0, 0, 0.12), 0 0 3px 0 rgba(0, 0, 0, 0.04);
      border-radius: 3px;
    }*/

    /*开启网格模式*/
    display: grid;

    /*设置成3列，每列宽度相同*/
    grid-template-columns: repeat(12, 1fr);

    /*虽然上面已经可以自动计算行数，但是这里还是可以设置行数和每行的高度*/
    grid-template-rows: calc(50% - 5px) calc(50% - 5px);

    /*设置row的最小高度和最大高度，最大高度取auto后便可以让row的高度自适应*/
    /*grid-auto-rows: minmax(60px, auto);*/

    /*设置每个item间隔*/
    grid-gap: $-layout-gap;

    /*设置网络区域（模板区域*/
    /*空白区域可以使用 . 符号占位*/
    grid-template-areas: "lt lt lt mct mct mct mct mct mct rt rt rt" "lb lb lb mcb mcb mcb mcb mcb mcb rb rb rb";

    .left-top {
      grid-area: lt;
    }

    .main-content-t {
      grid-area: mct;
    }

    .main-content-b {
      grid-area: mcb;
    }

    .right-top {
      grid-area: rt;
    }

    .left-bottom {
      grid-area: lb;
    }

    .right-bottom {
      grid-area: rb;
    }
  }
</style>