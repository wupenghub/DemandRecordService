<template>
  <el-menu
    :default-active="activeIndex"
    class="app-header app-menu"
    @select="handleSelect"
    :collapse="isCollapse"
    :background-color="theme.backgroundColor"
    :text-color="theme.textColor"
    :active-text-color="theme.activeTextColor"
    menu-trigger="click"
  >
    <navbar v-for="(item, index) in list" :key="item.id" :item="item"/>
  </el-menu>
</template>

<script>
  import navbar from "@/components/navhorizontal_item"
  import {menu} from '../menu'
  import {mapGetters, mapMutations} from 'vuex'

  export default {
    components: {navbar},
    inject: ['theme'],
    props: {
      isCollapse: {
        type: Boolean,
        default: false
      }
    },
    data() {
      return {
        list: util.rollTreeDatas(menu)
      };
    },
    created() {
      menu.forEach(t => {
        t.normalOpen && this.addTagViews(t)
      })
    },
    methods: {
      ...mapMutations({
        addTagViews: 'addTagViews',
        chgaCtiveTagView: 'activeTagView'
      }),
      /**
       * 顶部路由导航菜单选中后
       * 菜单返回一个path，遍历菜单，找到菜单具体内容
       * 给vuex添加激活的所有菜单（去重）
       * 给vuex添加档期啊激活的菜单
       * @param key
       * @param keyPath
       */
      handleSelect(key, keyPath) {
        let temp
        for (let i = 0, len = menu.length; i < len; i++) {
          if (menu[i].path === key) {
            temp = menu[i]
            break
          }
        }
        if (temp && !temp.location && this.openStyle === '0') {
          this.addTagViews(temp)
          this.chgaCtiveTagView(temp)
        }
      }
    },
    computed: {
      ...mapGetters(['activeTagView', 'openStyle']),
      activeIndex() {
        let index = this.activeTagView.path
        if (!index) {
          const hash = location.hash.slice(1)
          index = hash == "/" ? "/index" : hash
        }
        this.handleSelect(index)
        return index
      }
    }
  }
</script>

<style lang="less" scoped>
  .app-menu:not(.el-menu--collapse) {
    width: 210px;
    min-height: 400px;
  }

  .app-menu {
    height: 100%;
  }
</style>
