export const menu = [
  //  顶级菜单
  {
    name: '首页',
    id: '1',
    path: '/index',
    icon: 'el-icon-s-home',
    normalOpen: true
  },
  {
    name: '组件',
    id: '2',
    icon: 'el-icon-menu',
  },
  {
    name: '测试',
    id: '3',
    icon: 'el-icon-s-flag',
  },
  // {
  //   name: '百度',
  //   id: '4',
  //   location: true,
  //   icon: 'el-icon-link',
  //   path: 'https://www.baidu.com'
  // },
  //  二级菜单
  {
    name: '表格',
    id: '2-1', pid: '2',
    path: '/module/table',
    icon: 'el-icon-document'
  },
  {
    name: '导出Excel',
    id: '2-2',
    pid: '2',
    path: '/module/exportExcel',
    icon: 'el-icon-s-data'
  },
  {
    name: '网格布局',
    id: '2-3',
    pid: '2',
    path: '/module/grid',
    icon: 'el-icon-s-grid'
  },
  {
    name: '2-4',
    id: '2-4',
    pid: '2',
    icon: 'el-icon-connection',
  },
  {
    name: 'slot',
    id: '3-1',
    pid: '3',
    path: '/test/slot',
    icon: 'el-icon-connection'
  },
  //  三级菜单
  {
    name: '2-4-1',
    id: '2-4-1',
    pid: '2-4',
    disabled: true,
    path: '/module/4/1',
    icon: 'el-icon-connection'
  },
  {
    name: '2-4-2',
    id: '2-4-2',
    pid: '2-4',
    path: '/module/4/2',
    icon: 'el-icon-connection'
  },
  {
    name: '2-4-3',
    id: '2-4-3',
    pid: '2-4',
    path: '/module/4/3',
    icon: 'el-icon-connection'
  },
]