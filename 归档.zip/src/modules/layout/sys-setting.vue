<template>
  <el-form label-position="right" ref="form" :model="form" label-width="120px">
    <el-form-item label="页面打开方式：">
      <el-switch @change="changeOpenStyle" active-value="0" inactive-value="1" active-text="系统内部" inactive-text="新标签页"
                 v-model="form.openStyle"></el-switch>
    </el-form-item>

    <el-form-item label="主题：">
      <el-switch @change="changeThemeStyle" active-value="0" inactive-value="1" active-text="白天模式" inactive-text="夜晚模式"
                 v-model="form.themeStyle"></el-switch>
    </el-form-item>

    <el-form-item label="Layout设置：">
      <el-switch @change="changeLayoutStyle" active-value="0" inactive-value="1" active-text="顶部导航" inactive-text="侧边导航"
                 v-model="form.layoutStyle"></el-switch>
    </el-form-item>
  </el-form>
</template>
<script>
  import {mapGetters, mapMutations} from 'vuex'

  export default {
    data() {
      const getters = this.$store.getters
      return {
        form: {
          openStyle: getters.openStyle, // 0:系统内部；1：新标签页
          themeStyle: getters.themeStyle, // 0：白天模式；1：夜晚模式
          layoutStyle: getters.layoutStyle // 0：顶部导航；1：侧边导航
        }
      }
    },
    methods: {
      ...mapMutations(['setThemeStyle', 'setOpenStyle', 'setLayoutStyle']),
      /**
       * 修改页面打开方式
       * @param value
       */
      changeOpenStyle(value) {
        this.setOpenStyle(value)
      },
      /**
       * 修改主题
       * @param value
       */
      changeThemeStyle(value) {
        this.setThemeStyle(value)
      },
      /**
       * 修改页面layout方式
       * @param value
       */
      changeLayoutStyle(value) {
        this.setLayoutStyle(value)
      }
    },
    computed: {
      ...mapGetters(['themeStyle', 'openStyle', 'layoutStyle'])
    }
  }
</script>
