<template>
  <div class="rel">
    <el-scrollbar
      ref="scrollContainer"
      :vertical="false"
      class="scroll-container"
      @wheel.native.prevent="handleScroll"
    >
      <tab-link :visible.sync="visible"/>
    </el-scrollbar>
    <tab-close-menue
      @select="actionMenuSelect"
      class="upbit"
      :x="x"
      :y="y"
      :data="menuDataSource"
      v-show="visible.visible"
    />
  </div>
</template>

<script>
  import tabLink from './tab-link'
  import tabCloseMenue from './tab-close.vue'
  import {mapGetters, mapMutations} from 'vuex'

  export default {
    components: {tabLink, tabCloseMenue},
    inject: ['appReload'],
    data() {
      return {
        visible: {},
        x: 0,
        y: 40,
        actionView: {}, // 存储右键触发对应菜单信息
        menuDataSource: [
          {id: '1', label: '刷新页面', key: 'refresh'},
          {id: '2', label: '关闭当前', key: 'closeCurrent'},
          {id: '3', label: '关闭其他', key: 'closeOther'},
          {id: '4', label: '关闭所有', key: 'closeAll'}
        ]
      }
    },
    methods: {
      ...mapMutations({
        chgActiveTagView: 'activeTagView',
        deleteTagViews: 'deleteTagViews',
        changeTagViews: 'changeTagViews'
      }),
      handleScroll(e) {
        const eventDelta = e.wheelDelta || -e.deltaY * 40
        const $scrollWrapper = this.scrollWrapper
        $scrollWrapper.scrollLeft = $scrollWrapper.scrollLeft + eventDelta / 4
      },
      actionMenuSelect(select) {
        util.isFunction(this[select]) && this[select]()
        this.visible.visible = false
      },
      /**
       * 刷新导航对应的路由
       * 刷新未激活的导航，默认激活该导航
       */
      refresh() {
        let actionView = this.actionView
        if (this.activeTagView.id !== actionView.id) {
          this.chgActiveTagView(actionView)
          this.$router.replace({path: actionView.path})
        }
        this.appReload()
      },
      /**
       * 关闭当前路由
       */
      closeCurrent() {
        let actionView = this.actionView // 当前操作的菜单
        // 常开菜单不允许关闭
        if (actionView.normalOpen) {
          return
        }
        // 关闭的是当前激活的路由
        if (this.self) {
          let activeIndex = null, i = 0, len = this.tagViews.length
          for (; i < len; i++) {
            if (this.tagViews[i].id === actionView.id) {
              activeIndex = i
              break
            }
          }
          let nextViewIndex = activeIndex - 1
          this.chgActiveTagView(this.tagViews[nextViewIndex])
          this.$router.replace({path: this.tagViews[nextViewIndex].path})
          this.deleteTagViews(actionView.id)
          return
        }
        this.deleteTagViews(actionView.id)
      },
      /**
       * 关闭其他
       */
      closeOther() {
        let actionView = this.actionView, // 当前操作的菜单
            tagViews = this.tagViews, // 当前导航中所有的菜单
            newViews = tagViews.filter(t => (t.id === actionView.id || t.normalOpen)),
            len = newViews.length,
            lastViews = newViews[len - 1]
        if (len === tagViews.length) {
          return
        }
        this.chgActiveTagView(lastViews)
        this.$router.replace({path: lastViews.path})
        this.changeTagViews(newViews)
      },
      /**
       * 关闭所有
       */
      closeAll() {
        let tagViews = this.tagViews, // 当前导航中所有的菜单
            newViews = tagViews.filter(t => t.normalOpen),
            len = newViews.length,
            lastViews = newViews[len - 1]
        if (len === tagViews.length) {
          return
        }
        this.chgActiveTagView(lastViews)
        this.$router.replace({path: lastViews.path})
        this.changeTagViews(newViews)
      }
    },
    computed: {
      ...mapGetters(['activeTagView', 'tagViews']),
      scrollWrapper() {
        return this.$refs.scrollContainer.$refs.wrap
      },
      /**
       * 判断在导航栏右键选择的是否为激活导航菜单
       * @returns {boolean}
       */
      self() {
        return this.actionView.id === this.activeTagView.id
      }
    },
    watch: {
      'visible.data.id'() {
        let target = this.visible.e.target
        this.actionView = this.visible.data
        if (target.tagName === 'SPAN') {
          target = target.parentNode
        }
        this.x = target.offsetLeft
      }
    }
  }
</script>


<style lang="scss" scoped>
  .scroll-container {
    white-space: nowrap;
    position: relative;
    overflow: hidden;
    width: 100%;
    /deep/ {
      .el-scrollbar__bar {
        bottom: 0px;
      }
      .el-scrollbar__wrap {
        height: 65px;
      }
    }
  }

  @keyframes upbit {
    from {
      transform: translateY(20px);
    }

    to {
      transform: translateY(0);
    }
  }

  .upbit {
    animation: upbit 0.2s;
  }
</style>
