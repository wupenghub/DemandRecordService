<template>
  <ul :style="{left: x + 'px', top: y + 'px'}" class="prev-menue">
    <li v-for="item in data" @click="menuAction(item.key)" :key="item.id">{{ item.label }}</li>
  </ul>
</template>

<script>
  export default {
    props: {
      x: {
        type: Number,
        default: 0
      },
      y: {
        type: Number,
        default: 0
      },
      data: {
        type: Array,
        required: true
      }
    },
    data() {
      return {}
    },
    methods: {
      menuAction(fn) {
        this.$emit('select', fn)
      }
    }
  }
</script>

<style lang="less" scoped>
  .prev-menue {
    position: absolute;
    z-index: 999;
    background-color: #fff;
    border: 1px solid #ccc;
    /*padding: 5px 0px;*/
    font-size: 14px;
    border-radius: 3px;
    li {
      padding: 5px 15px;
      cursor: pointer;
      transition: all linear .1s;
      &:hover {
        background-color: #ccc;
      }
    }
  }
</style>
