<template>
  <div class="rel">
    <div id="tab-link">
      <template v-for="(tag, index) in tagViews">
        <router-link
          :to="tag.path"
          v-if="tag.path"
          :target="(tag.location || openStyle === '1') ? '_blank' : '_self'"
          class="router-link-s"
          :class="{active: activeTagView.id === tag.id}">
          <div
            @click.stop.prevenp="trgLink(tag)"
            @click.right.prevent.stop="showTagMenue(tag,$event)">
            <span
              :class="{ 'load-ok': tag.path === routerStatus.path, 'load-loading': tag.path !== routerStatus.path }">
            </span>
            <span>{{ tag.name }}</span>
            <span
              v-if="uniqueTagViews && !tag.normalOpen"
              @click.stop.prevent="deleteLink(tag, index)"
              class="close-link el-icon-close">
            </span>
          </div>
        </router-link>
      </template>
    </div>
  </div>
</template>

<script>
  import {mapGetters} from 'vuex'

  export default {
    data() {
      return {}
    },
    methods: {
      trgLink(tag) {
        this.$store.commit('activeTagView', tag)
      },
      deleteLink(tag, index) {
        if (tag.id === this.activeTagView.id) {
          const nextViewIndex = index !== 0 ? index - 1 : index + 1
          this.$store.commit('activeTagView', this.tagViews[nextViewIndex])
          this.$router.replace({path: this.tagViews[nextViewIndex].path})
        }
        this.$store.commit('deleteTagViews', tag.id)
      },
      showTagMenue(tag, $event) {
        this.$emit('update:visible', {visible: true, data: tag, e: $event})
      }
    },
    computed: {
      ...mapGetters(['tagViews', 'activeTagView', 'routerStatus', 'openStyle']),
      uniqueTagViews() {
        return this.tagViews.length > 1
      }
    }
  }
</script>

<style lang="less" scoped>
  #tab-link {
    display: flex;
    padding: 3px;
    font-size: 14px;
    border-bottom: 1px solid #ccc;
    box-shadow: 0 1px 3px 0 rgba(0, 0, 0, 0.12), 0 0 3px 0 rgba(0, 0, 0, 0.04);
    > a {
      border: 1px solid #ccc;
      margin-right: 3px;
    }
  }

  .router-link-s {
    display: block;
    height: 30px;
    line-height: 24px;
    > div {
      padding: 3px 10px;
    }
  }

  #tab-link .active {
    color: #fff;
    background-color: #409eff;
    border: none;
    transition: background linear .1s;
  }

  .load-ok, .load-loading {
    display: inline-block;
    width: 6px;
    height: 6px;
    border-radius: 50%;
  }

  .load-ok {
    background-color: #fff;
    border: none;
  }

  .load-loading {
    border: 1px solid #ccc;
  }

  .close-link {
    border-radius: 50%;
    display: inline-block;
    padding: 1px;
    transition: all linear .1s;
  }

  .close-link:hover {
    background-color: #ff582c;
    color: #fff;
  }
</style>
