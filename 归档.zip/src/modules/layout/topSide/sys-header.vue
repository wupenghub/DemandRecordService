<template>
  <el-header height="50px" class="app-header rel">
    <el-menu
      :default-active="activeIndex"
      class="app-header app-menu"
      mode="horizontal"
      @select="handleSelect"
      :background-color="theme.backgroundColor"
      :text-color="theme.textColor"
      :active-text-color="theme.activeTextColor"
      menu-trigger="click"
    >
      <navbar v-for="(item, index) in list" :key="item.id" :item="item"/>
    </el-menu>
    <user-action class="user-action"/>
  </el-header>
</template>

<script>
  import navbar from "@/components/navhorizontal_item"
  import userAction from '../user-action'
  import {menu} from '../menu'
  import {mapGetters, mapMutations} from 'vuex'

  export default {
    name: "sysHeader",
    inject: ['theme'],
    components: {navbar, userAction},
    data() {
      return {
        list: util.rollTreeDatas(menu)
      };
    },
    created() {
      menu.forEach(t => {
        t.normalOpen && this.addTagViews(t)
      })
    },
    methods: {
      ...mapMutations({
        addTagViews: 'addTagViews',
        chgaCtiveTagView: 'activeTagView'
      }),
      /**
       * 顶部路由导航菜单选中后
       * 菜单返回一个path，遍历菜单，找到菜单具体内容
       * 给vuex添加激活的所有菜单（去重）
       * 给vuex添加档期啊激活的菜单
       * @param key
       * @param keyPath
       */
      handleSelect(key, keyPath) {
        let temp
        for (let i = 0, len = menu.length; i < len; i++) {
          if (menu[i].path === key) {
            temp = menu[i]
            break
          }
        }
        if (temp && !temp.location && this.openStyle === '0') {
          this.addTagViews(temp)
          this.chgaCtiveTagView(temp)
        }
      }
    },
    computed: {
      ...mapGetters(['activeTagView', 'openStyle']),
      activeIndex() {
        let index = this.activeTagView.path
        if (!index) {
          const hash = location.hash.slice(1)
          index = hash == "/" ? "/index" : hash
        }
        this.handleSelect(index)
        return index
      }
    }
  };
</script>

<style lang="less" scoped>
  .el-header {
    padding: 0;
  }

  .app-header {
    display: flex;
    justify-content: center;
  }

  .app-menu {
    flex: 1;
  }

  .app-header /deep/ .el-menu.el-menu--horizontal {
    border-bottom: none;
  }

  .app-header /deep/ .el-menu--horizontal > .el-menu-item,
  .app-header /deep/ .el-menu--horizontal > .el-submenu .el-submenu__title {
    height: 50px;
    line-height: 50px;
  }

  .user-action {
    position: absolute;
    right: 0;
    top: 0;
    bottom: 0;
  }

  .el-menu-item /deep/ a {
    width: 100%;
    height: 100%;
    display: inline-block;
  }

</style>
