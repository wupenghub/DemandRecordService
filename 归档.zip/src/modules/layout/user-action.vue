<template>
  <ul class="app-user-action"
      :style="{backgroundColor: theme.backgroundColor, color: theme.textColor}">
    <li @click="sysSetting" title="系统设置" class="pointer el-icon-setting"></li>
    <li @click="refresh" title="刷新当前" class="pointer el-icon-refresh-right"></li>
    <li @click="fullSetting" :title="fullMsg" :class="fullClass" class="pointer"></li>
    <li is="el-drawer" title="系统设置" :visible.sync="drawer" direction="rtl">
      <setting/>
    </li>
    <li is="el-dropdown" class="user-drop-down">
      <user-avatar/>
    </li>
  </ul>
</template>

<script>
  import setting from './sys-setting'
  import userAvatar from './user-avatar'

  const full = util.fullScreen()

  export default {
    inject: ['theme', 'appReload'],
    components: {setting, userAvatar},
    data() {
      return {
        drawer: false,
        fullMsg: '',
        fullClass: ''
      }
    },
    mounted() {
      this.switchFullIcon()
      window.addEventListener('resize', () => {
        this.switchFullIcon()
      })
    },
    methods: {
      switchFullIcon () {
        if (this.isFullScreen()) {
          this.fullMsg = '退出全屏'
          this.fullClass = 'el-icon-copy-document'
        } else {
          this.fullMsg = '全屏'
          this.fullClass = 'el-icon-full-screen'
        }
      },
      isFullScreen() {
        return (document.body.scrollHeight == window.screen.height && document.body.scrollWidth == window.screen.width);
      },
      fullSetting() {
        if (this.isFullScreen()) {
          this.fullMsg = '全屏'
          this.fullClass = 'el-icon-full-screen'
          full.exit()
        } else {
          this.fullMsg = '退出全屏'
          this.fullClass = 'el-icon-copy-document'
          full.open()
        }
      },
      sysSetting() {
        this.drawer = true
      },
      refresh() {
        this.appReload()
      }
    }
  }
</script>

<style lang="less" scoped>
  .app-user-action {
    display: flex;
    align-items: center;
    li {
      margin: 0 10px;
      font-size: 18px;
    }

    .user-drop-down {
      cursor: pointer;
      margin: 0 20px;
    }
  }
</style>
