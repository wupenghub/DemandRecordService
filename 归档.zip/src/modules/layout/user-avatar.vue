<template>
  <div>
    <el-avatar :src="circleUrl" fit="cover"></el-avatar>
    <el-dropdown-menu slot="dropdown">
      <el-dropdown-item>修改密码</el-dropdown-item>
      <el-dropdown-item>个人信息</el-dropdown-item>
      <el-dropdown-item>退出登录</el-dropdown-item>
    </el-dropdown-menu>
  </div>
</template>

<script>
  import circleUrl from '@/imgs/logo.png'

  export default {
    data() {
      return {circleUrl}
    }
  }
</script>
