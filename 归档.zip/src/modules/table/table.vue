<template>
  <div class="block">
    <el-table
      :data="tableData"
      :height="height"
      :header-cell-style="tableHeaderStyle"
      size="small"
      style="width: 100%"
      border
      stripe
      v-loading="loading"
      element-loading-background="rgba(0, 0, 0, 0.1)"
    >
      <el-table-column
        type="selection"
        width="55"
        fixed="left"
        align="center"
        header-align="center"
      ></el-table-column>
      <el-table-column
        label="序号"
        type="index"
        width="100"
        align="center"
        :index="indexMethod"
      ></el-table-column>
      <el-table-column label="用户名" width="180" header-align="center" :show-overflow-tooltip="true">
        <template slot-scope="scope">
          <i class="el-icon-time"></i>
          <span style="margin-left: 10px">{{ scope.row.username }}</span>
        </template>
      </el-table-column>
      <el-table-column
        header-align="center"
        label="性别"
        width="180"
        prop="sex"
        :show-overflow-tooltip="true"
      ></el-table-column>

      <el-table-column
        header-align="center"
        label="城市"
        width="180"
        prop="city"
        :show-overflow-tooltip="true"
      ></el-table-column>

      <el-table-column
        header-align="center"
        label="签名"
        width="180"
        prop="sign"
        :show-overflow-tooltip="true"
      ></el-table-column>

      <el-table-column
        header-align="center"
        label="积分"
        width="180"
        prop="experience"
        :show-overflow-tooltip="true"
      ></el-table-column>

      <el-table-column
        header-align="center"
        label="评分"
        width="180"
        prop="score"
        :show-overflow-tooltip="true"
      ></el-table-column>

      <el-table-column
        header-align="center"
        label="职业"
        width="180"
        prop="classify"
        :show-overflow-tooltip="true"
      ></el-table-column>

      <el-table-column
        header-align="center"
        label="财富"
        width="180"
        prop="wealth"
        :show-overflow-tooltip="true"
      ></el-table-column>

      <el-table-column label="操作" width="200" align="center" header-align="center" fixed="right">
        <template slot-scope="scope">
          <el-button type="text" size="mini" @click="handleEdit(scope.$index, scope.row)">编辑</el-button>
          <el-button type="text" size="mini" @click="handleDelete(scope.$index, scope.row)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>
    <div class="block page-block">
      <el-pagination
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
        :current-page="pageNumber"
        :page-sizes="pageSizes"
        :page-size="size"
        :layout="tableLayout"
        :total="totalPage"
      ></el-pagination>
    </div>

    <table-detail
      :data="rowData"
      :visible.sync="detailVisible"
      :reloadTable="{reload: renderTable, pageNumber: this.pageNumber, size: this.size}"
    />
  </div>
</template>
<script>
  import * as MIX from '@/mix.js'
  import tableDetail from './tableDetail'

  const throttle = util.throttle()
  export default {
    mixins: [MIX.PAGEHANDLE()],
    components: {tableDetail},
    data() {
      return {
        tableData: [],
        totalPage: 0,
        loading: true,
        detailVisible: false,
        rowData: {}
      }
    },
    created() {
      this.renderTable()
    },
    computed: {
      height() {
        return window.innerHeight - 150
      }
    },
    methods: {
      /**
       * 编辑
       */
      handleEdit(index, row) {
        this.detailVisible = true
        this.rowData = row
        console.log(index, row)
      },
      /**
       * 删除
       */
      handleDelete(index, row) {
        this.$confirm('此操作将永久删除该文件, 是否继续?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          this.$message({
            type: 'success',
            message: '删除成功!'
          });
        }).catch(() => {
          this.$message({
            type: 'info',
            message: '已取消删除'
          })
        })
      },
      /**
       * 渲染列表
       */
      renderTable(page = 1, pageSize = 10) {
        throttle(() => {
          this.loading = true
          this.http({
            method: 'post',
            url: '/demo/table/user',
            method: 'get',
            params: {page: page, limit: pageSize}
          }).then(res => {
            this.totalPage = res.count || 0
            this.tableData = res.data
            setTimeout(() => {
              this.loading = false
            }, 300)
          })
        })
      }
    }
  }
</script>

<style scoped>
  .page-block {
    border: 1px solid #ebeef5;
    border-top: none;
    padding: 3px 0;
  }
</style>
