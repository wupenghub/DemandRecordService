<template>
  <el-dialog
    @close="closeDialog"
    title="详情"
    custom-class="el-detail-dialog"
    :close-on-press-escape="false"
    :modal="false"
    :close-on-click-modal="true"
    :visible.sync="dialogVisible"
    :fullscreen="false">
    <span>{{JSON.stringify(data)}}</span>
    <span slot="footer" class="dialog-footer">
      <el-button @click="closeDialog">取消</el-button>
      <el-button type="primary" @click="detailConfirm">确定</el-button>
    </span>
  </el-dialog>
</template>

<script>
  export default {
    props: ['visible', 'data', 'reloadTable'],
    data() {
      return {}
    },
    computed: {
      dialogVisible: {
        get() {
          return this.visible
        },
        set(val) {

        }
      }
    },
    methods: {
      detailConfirm() {
        // TODO 表单提交代码...
        const {reload, pageNumber, size} = this.reloadTable
        reload(pageNumber, size)
        this.closeDialog()
      },
      /**
       * 关闭弹出窗口
       */
      closeDialog() {
        this.$emit('update:visible', false)
      }
    }
  }
</script>
