let mutations = {
  /**
   * 新增路由导航预览
   * 存储的是菜单信息，不是路由信息
   * @param state
   * @param value
   */
  addTagViews(state, value) {
    let temp = state.tagViews
    temp.every(obj => (obj.id !== value.id && obj.path !== value.path)) && temp.push(value)
  },
  /**
   * 删除路由导航预览
   * 存储的是菜单信息，不是路由信息
   * @param state
   * @param value
   */
  deleteTagViews(state, value) {
    let views = state.tagViews
    //     , index = null
    // for (var i = 0, len = views.length; i < len; i++) {
    //   if (value === views[i].id) {
    //     index = i
    //     break
    //   }
    // }
    let index = views.findIndex(val => (value === val.id))
    index !== null && views.splice(index, 1)
  },
  /**
   * 替换路由导航预览
   * 存储的是菜单信息，不是路由信息
   * @param state
   * @param arr
   */
  changeTagViews(state, arr) {
    state.tagViews = arr
  },
  /**
   * 设置当前激活的路由菜单（是菜单，不是路由）
   * @param state
   * @param value
   */
  activeTagView(state, value) {
    state.activeTagView = value
  },
  /**
   * 存储已经加载OK 的路由信息（不是菜单）
   * @param state
   * @param value
   */
  routerStatus(state, value) {
    state.routerStatus = value
  },
  /**
   * 系统设置主题  0：白天模式；1：夜晚模式
   * @param state
   * @param value
   */
  setThemeStyle(state, value) {
    state.themeStyle = value
  },
  /**
   * 系统设置打开方式  0:系统内部；1：新标签页
   * @param state
   * @param value
   */
  setOpenStyle(state, value) {
    util.setCache('openstyle', value, {type: 'localStorage'})
    state.openStyle = value
  },
    /**
   * 系统布局方式 0：顶部导航；1：侧边导航
   * @param state
   * @param value
   */
  setLayoutStyle(state, value) {
    util.setCache('layoutStyle', value, {type: 'localStorage'})
    state.layoutStyle = value
  }
}

export default mutations
