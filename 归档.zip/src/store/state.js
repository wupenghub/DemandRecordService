let state = {
  // 获取节点views（已经打开过的路由，tag标签未关闭），是菜单信息，不是路由信息
  tagViews: [],
  // 当前激活的tagView（可能还在加载中），是菜单信息，不是路由信息
  activeTagView: {},
  // 当前加载OK的路由，是路由信息，不菜单是信息
  routerStatus: {},
  // 系统设置主题  0：白天模式；1：夜晚模式
  themeStyle: '0',
  // 系统设置打开方式  0:系统内部；1：新标签页
  openStyle: '0',
  // 系统布局方式 0：顶部导航；1：侧边导航
  layoutStyle: '0'
}

export default state
