var util = {}
/**
 * 判断数据类型
 * @param s
 * @returns {string}
 */
util.dataType = function (s) {
  return Object.prototype.toString.call(s).slice(8, -1).toLowerCase()
}

/**
 * 判断是否为字符串
 * @param s
 * @returns {boolean}
 */
util.isString = function (s) {
  return this.dataType(s) === 'string'
}

/**
 * 判断是否为函数
 * @param s
 * @returns {boolean}
 */
util.isFunction = function (s) {
  return this.dataType(s) === 'function'
}

/**
 * 获取URL中的参数
 * @param key
 * @param type [search | hash]
 * @returns {null}
 */
util.getQueryString = function (key, type) {
  type = type || 'search'
  var reg = new RegExp('(^|&)' + key + '=([^&]*)(&|$)', 'i')
  var r = window.location[type].substr(1).match(reg)
  if (r != null) {
    return unescape(r[2])
  }
  return ''
}

/**
 * 设置缓存
 * @param key
 * @param val
 * @param option
 */
util.setCache = function (key, val) {
  if (val === undefined) return;

  var option = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};

  var defaultOption = {
    type: 'sessionStorage',
    expiredays: null
  };
  option = Object.assign(defaultOption, option);
  var type = option.type,
      expiredays = option.expiredays;

  if (type === 'sessionStorage') {
    sessionStorage.setItem(key, val);
  } else if (type === 'localStorage') {
    localStorage.setItem(key, val);
  } else if (type === 'cookie') {
    var exdate = new Date();
    exdate.setDate(exdate.getDate() + expiredays);
    document.cookie = key + '=' + escape(val) + (expiredays === null ? '' : ';expires=' + exdate.toGMTString());
  }
}

/**
 * 获取缓存
 * @param key
 * @param option
 */
util.getCache = function (key) {
  var option = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};

  var defaultOption = {
    type: 'sessionStorage'
  };
  option = Object.assign(defaultOption, option);
  var type = option.type;

  var value = null;
  if (type === 'sessionStorage') {
    value = sessionStorage.getItem(key);
  } else if (type === 'localStorage') {
    value = localStorage.getItem(key);
  } else if (type === 'cookie') {
    if (document.cookie.length > 0) {
      var c_start = document.cookie.indexOf(key + '=');
      if (c_start !== -1) {
        c_start = c_start + key.length + 1;
        var c_end = document.cookie.indexOf(';', c_start);
        if (c_end === -1) {
          c_end = document.cookie.length;
        }
        value = unescape(document.cookie.substring(c_start, c_end));
      }
    }
  }
  return value;
}

/**
 * 删除缓存
 * @param key
 * @param option
 */
util.delCache = function (key, option) {
  option = option || {};
  var type = option.type || 'sessionStorage';
  if (type === 'sessionStorage') {
    sessionStorage.removeItem(key);
  } else if (type === 'localStorage') {
    localStorage.removeItem(key);
  } else if (type === 'cookie') {
    var cval = this.getCache(key, {
      type: 'cookie'
    });
    if (cval !== null) {
      this.setCache(key, cval, {
        type: 'cookie',
        expiredays: -1
      });
    }
  }
}

/**
 * 转换平级的json为多层嵌套的树状结构
 * @param data
 * @param option
 * var data = [
 *     {id: '1', name: 1},
 *     {id: '2', name: 1, pid: '1'},
 *     {id: '3', name: 1},
 *     {id: '4', name: 1},
 *     {id: '7', name: 1, pid: '2'},
 *     {id: '5', name: 1},
 *     {id: '6', name: 1, pid: '2'},
 *     {id: '8', name: 1, pid: '7'},
 *     {id: '9', name: 1, pid: '6'},
 *     {id: '10', name: 1, pid: '3'},
 *     {id: '11', name: 1, pid: '3'},
 * ]
 * console.log(G.rollTreeDatas(data));
 */
util.rollTreeDatas = function (data, option) {
  option = option || {}
  let ID = option.id || 'id'
      , PID = option.pid || 'pid'
      , CHILDREN = option.children || 'children'

  let store = {}
      , pids = []
      , tops = {}
      , fData = []

  // 有相同 "pid" 的整合到同一个数组中
  let i = 0, item
  for (; i < data.length, item = data[i]; i++) {
    let pid = item[PID]
    if (pid == '' || pid == null || pid == undefined) {
      tops[item[ID]] = item
    } else {
      pids.push(pid)
      if (store[pid]) {
        store[pid].push(item)
      } else {
        store[pid] = [item]
      }
    }
  }

  findChildren(tops)

  function findChildren(objs) {
    for (var key in objs) {
      if (store[objs[key][ID]]) {
        objs[key][CHILDREN] = store[objs[key][ID]]
        // delete store[objs[key][ID]]
        findChildren(objs[key][CHILDREN])
      }
    }
  }

  for (var key in tops) {
    fData.push(tops[key])
  }

  return fData
}

/**
 * 重写url中的search或hash
 */
util.rewriteParam = function () {
  var option = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
  var _option$type = option.type,
      type = _option$type === undefined ? 'hash' : _option$type,
      label = option.label,
      value = option.value;

  var urlParam = location[type]; // url中的querystring值或hash值
  // urlParam是否为空
  if (urlParam) {
    // urlParam是否已经有此字段
    var hasLabel = new RegExp(label).test(urlParam);

    if (hasLabel) {

      // 判断有字段且是否有 = 符号
      if (new RegExp(label + '=').test(urlParam)) {
        urlParam = urlParam.replace(new RegExp(label + '=[^&\?]*'), label + '=' + value);
      } else {
        urlParam = urlParam.replace(new RegExp(label), label + '=' + value);
      }
    } else {
      urlParam += '&' + label + '=' + value;
    }
  } else {
    urlParam = (type === 'hash' ? '#' : type === 'search' ? '?' : '') + label + '=' + value;
  }

  location[type] = urlParam;
}

/**
 * 开启、关闭浏览器全屏
 */
util.fullScreen = function () {
  function open() {
    var el = document.documentElement;
    var rfs = el.requestFullScreen
        || el.webkitRequestFullScreen
        || el.mozRequestFullScreen
        || el.msRequestFullScreen;
    if (typeof rfs != "undefined" && rfs) {
      rfs.call(el);
    } else if (typeof window.ActiveXObject != "undefined") {
      //for IE，这里其实就是模拟了按下键盘的F11，使浏览器全屏
      var wscript = new ActiveXObject("WScript.Shell");
      if (wscript != null) {
        wscript.SendKeys("{F11}");
      }
    }
  }

  function exit() {
    // 判断各种浏览器，找到正确的方法
    var exitMethod = document.exitFullscreen
        || document.mozCancelFullScreen
        || document.webkitExitFullscreen
        || document.webkitExitFullscreen;
    if (exitMethod) {
      exitMethod.call(document);
    } else if (typeof window.ActiveXObject !== "undefined") {
      //for Internet Explorer
      var wscript = new ActiveXObject("WScript.Shell");
      if (wscript !== null) {
        wscript.SendKeys("{F11}");
      }
    }
  }

  return {open: open, exit: exit};
}

/**
 * 给指定的容器设置文字水印背景
 * @param option
 */
util.setTextBg = function (option) {
  var dftText = this.getCache('userIp') + '_' + this.getCache('user')
  if (this.isString(option)) {
    option = {text: option || dftText}
  } else if (!option) {
    option = {}
  }

  var container = option.container || 'body'
      , height = option.height || 285
      , width = option.width || 220
      , font = option.font || 'bold 18px 宋体'
      , rotate = option.rotate || -45 * Math.PI / 180
      , fillStyle = option.fillStyle || 'rgba(0,0,0,.3)'
      , text = option.text || dftText
      , xoffset = option.xoffset || -100
      , yoffset = option.yoffset || 220
      , $body = $('body')
      , ctx
      , canvas = document.createElement('canvas')

  canvas.style.display = 'none'
  canvas.width = width
  canvas.height = height
  $body.prepend(canvas)

  if (!canvas.getContext) return
  ctx = canvas.getContext('2d')
  ctx.font = font
  ctx.rotate(rotate)
  ctx.fillStyle = fillStyle
  ctx.fillText(text, xoffset, yoffset)
  container.style.backgroundImage = 'url(' + ctx.canvas.toDataURL() + ')'
  canvas.parentNode.removeChild(canvas)
}

/**
 * 生成随机数
 * @param min
 * @param max
 * @returns {number}
 */
util.rand = function (min, max) {
  return Math.ceil(Math.random() * (max + 1 - min) + min - 1)
}

/**
 * 节流函数，
 * 可用于表单提交，防止重复提交
 * @param handler
 * @param wait
 * @returns {Function}
 */
util.throttle = function (wait) {
  wait = wait === undefined ? 1000 : wait
  var lastTime = 0
  return function (handler) {
    var nowTime = new Date().getTime()
    if (nowTime - lastTime > wait) {
      handler.apply(this, arguments)
      lastTime = nowTime
    }
  }
}

/**
 * 防抖动函数
 * 适用于搜索框搜索
 * @param handler
 * @param delay
 * @returns {Function}
 */
util.debounce = function (handler, delay) {
  delay = delay === undefined ? 500 : delay
  var timer
  return function () {
    var self = this, arg = arguments
    clearTimeout(timer)
    timer = setTimeout(function () {
      handler.apply(self, arg)
    }, delay)
  }
}

module.exports = util